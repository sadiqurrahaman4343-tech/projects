﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using ArcticBites.DataAccessLayer;

namespace ArcticBites
{
    public partial class ManageProductsForm : Form
    {
        DatabaseConnection db = new DatabaseConnection();

        public ManageProductsForm()
        {
            InitializeComponent();
        }

        private void ManageProductsForm_Load(object sender, EventArgs e)
        {
            LoadProducts();
            cmbStatus.SelectedIndex = 0;
        }

        private void LoadProducts()
        {
            try
            {
                SqlConnection con = db.GetConnection();

                string query = "SELECT IceCreamID, ProductName, Flavor, Category, Price, Stock, Status FROM IceCreams";

                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();

                adapter.Fill(dt);

                dgvProducts.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading product: " + ex.Message);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "" || txtFlavor.Text == "" || txtCategory.Text == "" ||
                txtPrice.Text == "" || txtStock.Text == "")
            {
                MessageBox.Show("Please fill all required fields.");
                return;
            }

            decimal price;
            int stock;

            if (!decimal.TryParse(txtPrice.Text, out price))
            {
                MessageBox.Show("Please enter a valid price.");
                return;
            }

            if (!int.TryParse(txtStock.Text, out stock))
            {
                MessageBox.Show("Please enter a valid stock quantity.");
                return;
            }

            if (price < 0)
            {
                MessageBox.Show("Price cannot be negative.");
                return;
            }

            if (stock < 0)
            {
                MessageBox.Show("Stock cannot be negative.");
                return;
            }

            try
            {
                SqlConnection con = db.GetConnection();

                string query = @"INSERT INTO IceCreams
                                (ProductName, Flavor, Category, Price, Stock, Status)
                                VALUES
                                (@ProductName, @Flavor, @Category, @Price, @Stock, @Status)";

                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@ProductName", txtName.Text);
                cmd.Parameters.AddWithValue("@Flavor", txtFlavor.Text);
                cmd.Parameters.AddWithValue("@Category", txtCategory.Text);
                cmd.Parameters.AddWithValue("@Price", price);
                cmd.Parameters.AddWithValue("@Stock", stock);
                cmd.Parameters.AddWithValue("@Status", cmbStatus.Text);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Product added successfully.");

                LoadProducts();
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding product: " + ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtProductID.Text == "")
            {
                MessageBox.Show("Please select a product first.");
                return;
            }

            if (txtName.Text == "" || txtFlavor.Text == "" || txtCategory.Text == "" ||
                txtPrice.Text == "" || txtStock.Text == "")
            {
                MessageBox.Show("Please fill all required fields.");
                return;
            }

            decimal price;
            int stock;

            if (!decimal.TryParse(txtPrice.Text, out price))
            {
                MessageBox.Show("Please enter a valid price.");
                return;
            }

            if (!int.TryParse(txtStock.Text, out stock))
            {
                MessageBox.Show("Please enter a valid stock quantity.");
                return;
            }

            if (price < 0)
            {
                MessageBox.Show("Price cannot be negative.");
                return;
            }

            if (stock < 0)
            {
                MessageBox.Show("Stock cannot be negative.");
                return;
            }

            try
            {
                SqlConnection con = db.GetConnection();

                string query = @"UPDATE IceCreams
                                SET ProductName = @ProductName,
                                    Flavor = @Flavor,
                                    Category = @Category,
                                    Price = @Price,
                                    Stock = @Stock,
                                    Status = @Status,
                                    UpdatedAt = GETDATE()
                                WHERE IceCreamID = @IceCreamID";

                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@IceCreamID", txtProductID.Text);
                cmd.Parameters.AddWithValue("@ProductName", txtName.Text);
                cmd.Parameters.AddWithValue("@Flavor", txtFlavor.Text);
                cmd.Parameters.AddWithValue("@Category", txtCategory.Text);
                cmd.Parameters.AddWithValue("@Price", price);
                cmd.Parameters.AddWithValue("@Stock", stock);
                cmd.Parameters.AddWithValue("@Status", cmbStatus.Text);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Product updated successfully.");

                LoadProducts();
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating the product: " + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtProductID.Text == "")
            {
                MessageBox.Show("Please select an ice cream first.");
                return;
            }

            try
            {
                SqlConnection con = db.GetConnection();

                // We are not permanently deleting the Product.
                // We are only making the Ice Cream unavailable.
                string query = @"UPDATE IceCreams
                                SET Status = 'Unavailable',
                                    UpdatedAt = GETDATE()
                                WHERE IceCreamID = @IceCreamID";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@IceCreamID", txtProductID.Text);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Product marked as unavailable.");

                LoadProducts();
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting the product: " + ex.Message);
            }
        }

        private void btnMakeAvailable_Click(object sender, EventArgs e)
        {
            if (txtProductID.Text == "")
            {
                MessageBox.Show("Please select an ice cream first.");
                return;
            }

            try
            {
                SqlConnection con = db.GetConnection();

                string query = @"UPDATE IceCreams
                                SET Status = 'Available',
                                    UpdatedAt = GETDATE()
                                WHERE IceCreamID = @IceCreamID";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@IceCreamID", txtProductID.Text);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Ice Cream is now available.");

                LoadProducts();
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error making the product available: " + ex.Message);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = db.GetConnection();

                string query = @"SELECT IceCreamID, ProductName, Flavor, Category, Price, Stock, Status
                                FROM IceCreams
                                WHERE ProductName LIKE @Search
                                   OR Flavor LIKE @Search
                                   OR Category LIKE @Search";

                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                adapter.SelectCommand.Parameters.AddWithValue("@Search", "%" + txtSearch.Text + "%");

                DataTable dt = new DataTable();
                adapter.Fill(dt);

                dgvProducts.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error searching the product: " + ex.Message);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadProducts();
            ClearFields();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void ClearFields()
        {
            txtProductID.Clear();
            txtName.Clear();
            txtFlavor.Clear();
            txtCategory.Clear();
            txtPrice.Clear();
            txtStock.Clear();
            txtSearch.Clear();

            if (cmbStatus.Items.Count > 0)
            {
                cmbStatus.SelectedIndex = 0;
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            // This part is commented because ManagerDashboard may not be ready yet.
            // When ManagerDashboard is ready, remove the comments and use this code.


            ManagerDashboard managerDashboard = new ManagerDashboard();
            managerDashboard.Show();
            this.Hide();



        }

        private void txtBookID_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblBookTitle_Click(object sender, EventArgs e)
        {

        }

        private void txtTitle_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblAuthor_Click(object sender, EventArgs e)
        {

        }

        private void txtAuthor_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblCategory_Click(object sender, EventArgs e)
        {

        }

        private void txtCategory_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblPrice_Click(object sender, EventArgs e)
        {

        }

        private void txtPrice_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblStock_Click(object sender, EventArgs e)
        {

        }

        private void txtStock_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblStatus_Click(object sender, EventArgs e)
        {

        }

        private void cmbStatus_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void lblBookID_Click(object sender, EventArgs e)
        {

        }

        private void lblSearch_Click(object sender, EventArgs e)
        {

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgvProducts_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvProducts.Rows[e.RowIndex];

                txtProductID.Text = row.Cells["IceCreamID"].Value.ToString();
                txtName.Text = row.Cells["ProductName"].Value.ToString();
                txtFlavor.Text = row.Cells["Flavor"].Value.ToString();
                txtCategory.Text = row.Cells["Category"].Value.ToString();
                txtPrice.Text = row.Cells["Price"].Value.ToString();
                txtStock.Text = row.Cells["Stock"].Value.ToString();
                cmbStatus.Text = row.Cells["Status"].Value.ToString();
            }
        }
    }
}