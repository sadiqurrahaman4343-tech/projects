using System.Data.SqlClient;

namespace ArcticBites.DataAccessLayer
{
    public class DatabaseConnection
    {
        private string connectionString = @"Data Source=LAPTOP-P6IIBLR3\SQLEXPRESS;Initial Catalog=IceCreamShopDB;Integrated Security=True;Encrypt=False";

        public SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }
    }
}