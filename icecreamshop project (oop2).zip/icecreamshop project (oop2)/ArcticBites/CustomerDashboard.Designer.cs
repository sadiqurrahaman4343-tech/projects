﻿namespace ArcticBites { 
    partial class CustomerDashboard
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblWelcome;

        private System.Windows.Forms.Button btnBrowseProducts;
        private System.Windows.Forms.Button btnCart;
        private System.Windows.Forms.Button btnOrderHistory;
        private System.Windows.Forms.Button btnProfile;
        private System.Windows.Forms.Button btnLogout;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.btnBrowseProducts = new System.Windows.Forms.Button();
            this.btnCart = new System.Windows.Forms.Button();
            this.btnOrderHistory = new System.Windows.Forms.Button();
            this.btnProfile = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.lblBrowseProducts = new System.Windows.Forms.Label();
            this.lblViewCart = new System.Windows.Forms.Label();
            this.lblProfile = new System.Windows.Forms.Label();
            this.lblOrderHistory = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.lblTitle.Location = new System.Drawing.Point(252, 66);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(356, 46);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Customer Dashboard";
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblWelcome.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lblWelcome.Location = new System.Drawing.Point(274, 123);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(312, 28);
            this.lblWelcome.TabIndex = 1;
            this.lblWelcome.Text = "welcome, our favourite customer :)";
            this.lblWelcome.Click += new System.EventHandler(this.lblWelcome_Click);
            // 
            // btnBrowseProducts
            // 
            this.btnBrowseProducts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.btnBrowseProducts.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnBrowseProducts.ForeColor = System.Drawing.Color.Snow;
            this.btnBrowseProducts.Location = new System.Drawing.Point(96, 258);
            this.btnBrowseProducts.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnBrowseProducts.Name = "btnBrowseProducts";
            this.btnBrowseProducts.Size = new System.Drawing.Size(196, 36);
            this.btnBrowseProducts.TabIndex = 2;
            this.btnBrowseProducts.Text = "Browse Products";
            this.btnBrowseProducts.UseVisualStyleBackColor = false;
            this.btnBrowseProducts.Click += new System.EventHandler(this.btnBrowseBooks_Click);
            // 
            // btnCart
            // 
            this.btnCart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.btnCart.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnCart.ForeColor = System.Drawing.Color.Snow;
            this.btnCart.Location = new System.Drawing.Point(589, 258);
            this.btnCart.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCart.Name = "btnCart";
            this.btnCart.Size = new System.Drawing.Size(196, 36);
            this.btnCart.TabIndex = 3;
            this.btnCart.Text = "View Cart";
            this.btnCart.UseVisualStyleBackColor = false;
            this.btnCart.Click += new System.EventHandler(this.btnCart_Click);
            // 
            // btnOrderHistory
            // 
            this.btnOrderHistory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.btnOrderHistory.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnOrderHistory.ForeColor = System.Drawing.Color.Snow;
            this.btnOrderHistory.Location = new System.Drawing.Point(96, 429);
            this.btnOrderHistory.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnOrderHistory.Name = "btnOrderHistory";
            this.btnOrderHistory.Size = new System.Drawing.Size(196, 36);
            this.btnOrderHistory.TabIndex = 4;
            this.btnOrderHistory.Text = "Order History";
            this.btnOrderHistory.UseVisualStyleBackColor = false;
            this.btnOrderHistory.Click += new System.EventHandler(this.btnOrderHistory_Click);
            // 
            // btnProfile
            // 
            this.btnProfile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.btnProfile.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnProfile.ForeColor = System.Drawing.Color.Snow;
            this.btnProfile.Location = new System.Drawing.Point(589, 429);
            this.btnProfile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(196, 36);
            this.btnProfile.TabIndex = 5;
            this.btnProfile.Text = "Profile";
            this.btnProfile.UseVisualStyleBackColor = false;
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.btnLogout.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnLogout.ForeColor = System.Drawing.Color.Snow;
            this.btnLogout.Location = new System.Drawing.Point(336, 546);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(196, 36);
            this.btnLogout.TabIndex = 6;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // lblBrowseProducts
            // 
            this.lblBrowseProducts.AutoSize = true;
            this.lblBrowseProducts.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBrowseProducts.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lblBrowseProducts.Location = new System.Drawing.Point(92, 296);
            this.lblBrowseProducts.Name = "lblBrowseProducts";
            this.lblBrowseProducts.Size = new System.Drawing.Size(206, 46);
            this.lblBrowseProducts.TabIndex = 7;
            this.lblBrowseProducts.Text = "browse and order from our\r\nvarious flavored ice creams";
            // 
            // lblViewCart
            // 
            this.lblViewCart.AutoSize = true;
            this.lblViewCart.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViewCart.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lblViewCart.Location = new System.Drawing.Point(604, 296);
            this.lblViewCart.Name = "lblViewCart";
            this.lblViewCart.Size = new System.Drawing.Size(181, 46);
            this.lblViewCart.TabIndex = 8;
            this.lblViewCart.Text = "view the items that you\r\nhave added to cart";
            // 
            // lblProfile
            // 
            this.lblProfile.AutoSize = true;
            this.lblProfile.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProfile.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lblProfile.Location = new System.Drawing.Point(604, 467);
            this.lblProfile.Name = "lblProfile";
            this.lblProfile.Size = new System.Drawing.Size(161, 46);
            this.lblProfile.TabIndex = 10;
            this.lblProfile.Text = "view or update your\r\ncurrent informations";
            // 
            // lblOrderHistory
            // 
            this.lblOrderHistory.AutoSize = true;
            this.lblOrderHistory.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrderHistory.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lblOrderHistory.Location = new System.Drawing.Point(101, 467);
            this.lblOrderHistory.Name = "lblOrderHistory";
            this.lblOrderHistory.Size = new System.Drawing.Size(176, 46);
            this.lblOrderHistory.TabIndex = 9;
            this.lblOrderHistory.Text = "view your order history\r\nfrom past orders";
            // 
            // CustomerDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Snow;
            this.ClientSize = new System.Drawing.Size(902, 638);
            this.Controls.Add(this.lblProfile);
            this.Controls.Add(this.lblOrderHistory);
            this.Controls.Add(this.lblViewCart);
            this.Controls.Add(this.lblBrowseProducts);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.btnBrowseProducts);
            this.Controls.Add(this.btnCart);
            this.Controls.Add(this.btnOrderHistory);
            this.Controls.Add(this.btnProfile);
            this.Controls.Add(this.btnLogout);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "CustomerDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer Dashboard";
            this.Load += new System.EventHandler(this.CustomerDashboard_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Label lblBrowseProducts;
        private System.Windows.Forms.Label lblViewCart;
        private System.Windows.Forms.Label lblProfile;
        private System.Windows.Forms.Label lblOrderHistory;
    }
}