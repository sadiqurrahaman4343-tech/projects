﻿namespace ArcticBites
{
    partial class CartForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblTitle;

        private System.Windows.Forms.Label lblCartItemID;
        private System.Windows.Forms.Label lblIceCreamID;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.Label lblFlavor;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.Label lblAvailableStock;
        private System.Windows.Forms.Label lblSubTotal;
        private System.Windows.Forms.Label lblTotalAmount;
        private System.Windows.Forms.Label lblTotalAmountValue;

        private System.Windows.Forms.TextBox txtCartItemID;
        private System.Windows.Forms.TextBox txtIceCreamID;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.TextBox txtFlavor;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.TextBox txtQuantity;
        private System.Windows.Forms.TextBox txtAvailableStock;
        private System.Windows.Forms.TextBox txtSubTotal;

        private System.Windows.Forms.Button btnUpdateQuantity;
        private System.Windows.Forms.Button btnRemoveItem;
        private System.Windows.Forms.Button btnPlaceOrder;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnBack;

        private System.Windows.Forms.DataGridView dgvCartItems;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblCartItemID = new System.Windows.Forms.Label();
            this.lblIceCreamID = new System.Windows.Forms.Label();
            this.lblProductName = new System.Windows.Forms.Label();
            this.lblFlavor = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.lblAvailableStock = new System.Windows.Forms.Label();
            this.lblSubTotal = new System.Windows.Forms.Label();
            this.lblTotalAmount = new System.Windows.Forms.Label();
            this.lblTotalAmountValue = new System.Windows.Forms.Label();
            this.txtCartItemID = new System.Windows.Forms.TextBox();
            this.txtIceCreamID = new System.Windows.Forms.TextBox();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.txtFlavor = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            this.txtAvailableStock = new System.Windows.Forms.TextBox();
            this.txtSubTotal = new System.Windows.Forms.TextBox();
            this.btnUpdateQuantity = new System.Windows.Forms.Button();
            this.btnRemoveItem = new System.Windows.Forms.Button();
            this.btnPlaceOrder = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.dgvCartItems = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCartItems)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(417, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(78, 41);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Cart";
            // 
            // lblCartItemID
            // 
            this.lblCartItemID.AutoSize = true;
            this.lblCartItemID.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblCartItemID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.lblCartItemID.Location = new System.Drawing.Point(66, 450);
            this.lblCartItemID.Name = "lblCartItemID";
            this.lblCartItemID.Size = new System.Drawing.Size(104, 23);
            this.lblCartItemID.TabIndex = 1;
            this.lblCartItemID.Text = "Cart Item ID";
            // 
            // lblIceCreamID
            // 
            this.lblIceCreamID.AutoSize = true;
            this.lblIceCreamID.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblIceCreamID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.lblIceCreamID.Location = new System.Drawing.Point(66, 482);
            this.lblIceCreamID.Name = "lblIceCreamID";
            this.lblIceCreamID.Size = new System.Drawing.Size(92, 23);
            this.lblIceCreamID.TabIndex = 3;
            this.lblIceCreamID.Text = "Product ID";
            // 
            // lblProductName
            // 
            this.lblProductName.AutoSize = true;
            this.lblProductName.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblProductName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.lblProductName.Location = new System.Drawing.Point(66, 514);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(56, 23);
            this.lblProductName.TabIndex = 5;
            this.lblProductName.Text = "Name";
            // 
            // lblFlavor
            // 
            this.lblFlavor.AutoSize = true;
            this.lblFlavor.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblFlavor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.lblFlavor.Location = new System.Drawing.Point(66, 546);
            this.lblFlavor.Name = "lblFlavor";
            this.lblFlavor.Size = new System.Drawing.Size(55, 23);
            this.lblFlavor.TabIndex = 7;
            this.lblFlavor.Text = "Flavor";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblPrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.lblPrice.Location = new System.Drawing.Point(66, 578);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(47, 23);
            this.lblPrice.TabIndex = 9;
            this.lblPrice.Text = "Price";
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblQuantity.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.lblQuantity.Location = new System.Drawing.Point(533, 450);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(76, 23);
            this.lblQuantity.TabIndex = 11;
            this.lblQuantity.Text = "Quantity";
            // 
            // lblAvailableStock
            // 
            this.lblAvailableStock.AutoSize = true;
            this.lblAvailableStock.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblAvailableStock.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.lblAvailableStock.Location = new System.Drawing.Point(533, 482);
            this.lblAvailableStock.Name = "lblAvailableStock";
            this.lblAvailableStock.Size = new System.Drawing.Size(123, 23);
            this.lblAvailableStock.TabIndex = 13;
            this.lblAvailableStock.Text = "Available Stock";
            // 
            // lblSubTotal
            // 
            this.lblSubTotal.AutoSize = true;
            this.lblSubTotal.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSubTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.lblSubTotal.Location = new System.Drawing.Point(533, 514);
            this.lblSubTotal.Name = "lblSubTotal";
            this.lblSubTotal.Size = new System.Drawing.Size(80, 23);
            this.lblSubTotal.TabIndex = 15;
            this.lblSubTotal.Text = "Sub Total";
            // 
            // lblTotalAmount
            // 
            this.lblTotalAmount.AutoSize = true;
            this.lblTotalAmount.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblTotalAmount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.lblTotalAmount.Location = new System.Drawing.Point(501, 576);
            this.lblTotalAmount.Name = "lblTotalAmount";
            this.lblTotalAmount.Size = new System.Drawing.Size(133, 25);
            this.lblTotalAmount.TabIndex = 17;
            this.lblTotalAmount.Text = "Total Amount";
            // 
            // lblTotalAmountValue
            // 
            this.lblTotalAmountValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotalAmountValue.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblTotalAmountValue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.lblTotalAmountValue.Location = new System.Drawing.Point(649, 574);
            this.lblTotalAmountValue.Name = "lblTotalAmountValue";
            this.lblTotalAmountValue.Size = new System.Drawing.Size(196, 24);
            this.lblTotalAmountValue.TabIndex = 18;
            this.lblTotalAmountValue.Text = "0.00";
            this.lblTotalAmountValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtCartItemID
            // 
            this.txtCartItemID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.txtCartItemID.Location = new System.Drawing.Point(172, 450);
            this.txtCartItemID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCartItemID.Name = "txtCartItemID";
            this.txtCartItemID.ReadOnly = true;
            this.txtCartItemID.Size = new System.Drawing.Size(196, 22);
            this.txtCartItemID.TabIndex = 2;
            // 
            // txtIceCreamID
            // 
            this.txtIceCreamID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.txtIceCreamID.Location = new System.Drawing.Point(172, 482);
            this.txtIceCreamID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtIceCreamID.Name = "txtIceCreamID";
            this.txtIceCreamID.ReadOnly = true;
            this.txtIceCreamID.Size = new System.Drawing.Size(196, 22);
            this.txtIceCreamID.TabIndex = 4;
            // 
            // txtProductName
            // 
            this.txtProductName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.txtProductName.Location = new System.Drawing.Point(172, 514);
            this.txtProductName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.ReadOnly = true;
            this.txtProductName.Size = new System.Drawing.Size(196, 22);
            this.txtProductName.TabIndex = 6;
            // 
            // txtFlavor
            // 
            this.txtFlavor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.txtFlavor.Location = new System.Drawing.Point(172, 546);
            this.txtFlavor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtFlavor.Name = "txtFlavor";
            this.txtFlavor.ReadOnly = true;
            this.txtFlavor.Size = new System.Drawing.Size(196, 22);
            this.txtFlavor.TabIndex = 8;
            // 
            // txtPrice
            // 
            this.txtPrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.txtPrice.Location = new System.Drawing.Point(172, 578);
            this.txtPrice.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.ReadOnly = true;
            this.txtPrice.Size = new System.Drawing.Size(196, 22);
            this.txtPrice.TabIndex = 10;
            // 
            // txtQuantity
            // 
            this.txtQuantity.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.txtQuantity.Location = new System.Drawing.Point(649, 450);
            this.txtQuantity.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(196, 22);
            this.txtQuantity.TabIndex = 12;
            // 
            // txtAvailableStock
            // 
            this.txtAvailableStock.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.txtAvailableStock.Location = new System.Drawing.Point(649, 482);
            this.txtAvailableStock.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAvailableStock.Name = "txtAvailableStock";
            this.txtAvailableStock.ReadOnly = true;
            this.txtAvailableStock.Size = new System.Drawing.Size(196, 22);
            this.txtAvailableStock.TabIndex = 14;
            // 
            // txtSubTotal
            // 
            this.txtSubTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.txtSubTotal.Location = new System.Drawing.Point(649, 514);
            this.txtSubTotal.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSubTotal.Name = "txtSubTotal";
            this.txtSubTotal.ReadOnly = true;
            this.txtSubTotal.Size = new System.Drawing.Size(196, 22);
            this.txtSubTotal.TabIndex = 16;
            // 
            // btnUpdateQuantity
            // 
            this.btnUpdateQuantity.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.btnUpdateQuantity.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnUpdateQuantity.ForeColor = System.Drawing.Color.Snow;
            this.btnUpdateQuantity.Location = new System.Drawing.Point(46, 375);
            this.btnUpdateQuantity.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.btnUpdateQuantity.Name = "btnUpdateQuantity";
            this.btnUpdateQuantity.Size = new System.Drawing.Size(124, 30);
            this.btnUpdateQuantity.TabIndex = 19;
            this.btnUpdateQuantity.Text = "Update Quantity";
            this.btnUpdateQuantity.UseVisualStyleBackColor = false;
            this.btnUpdateQuantity.Click += new System.EventHandler(this.btnUpdateQuantity_Click);
            // 
            // btnRemoveItem
            // 
            this.btnRemoveItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.btnRemoveItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnRemoveItem.ForeColor = System.Drawing.Color.Snow;
            this.btnRemoveItem.Location = new System.Drawing.Point(201, 375);
            this.btnRemoveItem.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.btnRemoveItem.Name = "btnRemoveItem";
            this.btnRemoveItem.Size = new System.Drawing.Size(116, 30);
            this.btnRemoveItem.TabIndex = 20;
            this.btnRemoveItem.Text = "Remove Item";
            this.btnRemoveItem.UseVisualStyleBackColor = false;
            this.btnRemoveItem.Click += new System.EventHandler(this.btnRemoveItem_Click);
            // 
            // btnPlaceOrder
            // 
            this.btnPlaceOrder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.btnPlaceOrder.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnPlaceOrder.ForeColor = System.Drawing.Color.Snow;
            this.btnPlaceOrder.Location = new System.Drawing.Point(335, 375);
            this.btnPlaceOrder.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.btnPlaceOrder.Name = "btnPlaceOrder";
            this.btnPlaceOrder.Size = new System.Drawing.Size(116, 30);
            this.btnPlaceOrder.TabIndex = 21;
            this.btnPlaceOrder.Text = "Place Order";
            this.btnPlaceOrder.UseVisualStyleBackColor = false;
            this.btnPlaceOrder.Click += new System.EventHandler(this.btnPlaceOrder_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.btnRefresh.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnRefresh.ForeColor = System.Drawing.Color.Snow;
            this.btnRefresh.Location = new System.Drawing.Point(486, 375);
            this.btnRefresh.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(98, 30);
            this.btnRefresh.TabIndex = 22;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.btnClear.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnClear.ForeColor = System.Drawing.Color.Snow;
            this.btnClear.Location = new System.Drawing.Point(623, 375);
            this.btnClear.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(98, 30);
            this.btnClear.TabIndex = 23;
            this.btnClear.Text = "Clear Fields";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(33)))), ((int)(((byte)(61)))));
            this.btnBack.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnBack.ForeColor = System.Drawing.Color.Snow;
            this.btnBack.Location = new System.Drawing.Point(765, 375);
            this.btnBack.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(80, 30);
            this.btnBack.TabIndex = 24;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // dgvCartItems
            // 
            this.dgvCartItems.AllowUserToAddRows = false;
            this.dgvCartItems.AllowUserToDeleteRows = false;
            this.dgvCartItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCartItems.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dgvCartItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCartItems.Location = new System.Drawing.Point(45, 65);
            this.dgvCartItems.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgvCartItems.Name = "dgvCartItems";
            this.dgvCartItems.ReadOnly = true;
            this.dgvCartItems.RowHeadersWidth = 62;
            this.dgvCartItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCartItems.Size = new System.Drawing.Size(831, 279);
            this.dgvCartItems.TabIndex = 26;
            this.dgvCartItems.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCartItems_CellClick);
            // 
            // CartForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Snow;
            this.ClientSize = new System.Drawing.Size(902, 638);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblCartItemID);
            this.Controls.Add(this.txtCartItemID);
            this.Controls.Add(this.lblIceCreamID);
            this.Controls.Add(this.txtIceCreamID);
            this.Controls.Add(this.lblProductName);
            this.Controls.Add(this.txtProductName);
            this.Controls.Add(this.lblFlavor);
            this.Controls.Add(this.txtFlavor);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.lblQuantity);
            this.Controls.Add(this.txtQuantity);
            this.Controls.Add(this.lblAvailableStock);
            this.Controls.Add(this.txtAvailableStock);
            this.Controls.Add(this.lblSubTotal);
            this.Controls.Add(this.txtSubTotal);
            this.Controls.Add(this.lblTotalAmount);
            this.Controls.Add(this.lblTotalAmountValue);
            this.Controls.Add(this.btnUpdateQuantity);
            this.Controls.Add(this.btnRemoveItem);
            this.Controls.Add(this.btnPlaceOrder);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.dgvCartItems);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "CartForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cart";
            this.Load += new System.EventHandler(this.CartForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCartItems)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}